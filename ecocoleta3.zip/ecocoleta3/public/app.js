const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MATS={plastico:['Plástico','🧴'],papelao:['Papelão','📦'],metal:['Metal','🥫'],cobre:['Cobre','🔌'],eletronico:['Eletrônicos','💻'],outros:['Outros','♻️']};
const ST={disponivel:'Disponível',agendada:'Agendada',caminho:'A caminho',concluida:'Concluída'};
/* Fotos reais: 1) enviada pelo usuário  2) public/fotos/<material>.jpg  3) Wikimedia Commons (CC BY-SA) */
const COMMONS={plastico:'Bales_of_PET_bottles_closeup.jpg',metal:'Steel_recycling_bales.jpg'};
const cm=f=>`https://commons.wikimedia.org/wiki/Special:FilePath/${f}?width=640`;
const BASE={lat:-13.3697,lng:-39.0731};
let me=null,ES=null,MAPS=[],Q=[],UM=null,CM=null,wid=null,lastPost=0,PH='',PA='',AV=1,tmr;
let S={tab:'h',f:'',sort:'dist',mode:'',rad:'',q:'',sheet:null,chat:null,pos:null,gps:'off',reg:false,ads:[],mine:[],cats:[],chats:[],msgs:[],notifs:[],unseen:0,panel:false,loc:null};
const P=()=>S.pos||BASE;
async function api(m,p,b){const r=await fetch('/api'+p,{method:m,headers:b?{'Content-Type':'application/json'}:{},body:b?JSON.stringify(b):undefined});let j={};try{j=await r.json()}catch(e){}
if(r.status===401&&me){me=null;render()}if(!r.ok)throw new Error(j.error||'Falha de conexão');return j}
const toast=t=>{const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',5000)};
const T=f=>async(...a)=>{try{return await f(...a)}catch(e){toast(e.message)}};
const fmtKm=d=>d==null?'':d<1?Math.round(d*1000)+' m':d.toFixed(1)+' km';
const eta=d=>{const m=Math.max(1,Math.round(d/5*60));return m>=60?Math.floor(m/60)+' h '+(m%60)+' min':m+' min'};
const hv=(a,b)=>{const r=x=>x*Math.PI/180,h=Math.sin(r(b.lat-a.lat)/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(r(b.lng-a.lng)/2)**2;return 12742*Math.asin(Math.sqrt(h))};

/* ---------- imagens ---------- */
const srcs=a=>[a.has_photo&&`/api/photo/ad/${a.id}?v=${a.v}`,`fotos/${a.mat}.jpg`,COMMONS[a.mat]&&cm(COMMONS[a.mat])].filter(Boolean);
const pic=(a,c)=>{const s=srcs(a);return `<div class="pic ${c}"><i>${MATS[a.mat][1]}</i><img alt="${MATS[a.mat][0]}" loading="lazy" src="${s[0]}" data-fb="${esc(JSON.stringify(s.slice(1)))}" onerror="fb(this)"></div>`};
function fb(i){const l=JSON.parse(i.dataset.fb||'[]');if(l.length){i.dataset.fb=JSON.stringify(l.slice(1));i.src=l[0]}else i.remove()}
const av=(u,c)=>`<span class="${c||'a'}">${u.has_avatar?`<img alt="" src="/api/photo/user/${u.id}?v=${AV}" onerror="this.remove()">`:esc((u.name||'?')[0].toUpperCase())}</span>`;
const who=u=>`<div class="who">${av(u)}<span>${esc(u.name)} ${u.kind==='empresa'?'· 🏢 Empresa':''}</span></div>`;

/* ---------- inicialização ---------- */
async function boot(){try{me=(await api('GET','/me')).user}catch(e){}if(me)start();render()}
function start(){S.tab=me.role==='catador'?'h':'n';gps();sse();loadNotifs();load();
try{if(me.role==='catador'&&'Notification' in window&&Notification.permission==='default')Notification.requestPermission()}catch(e){}}
function sse(){if(ES)ES.close();ES=new EventSource('/api/stream');
ES.addEventListener('notif',e=>{const d=JSON.parse(e.data);toast('🔔 '+d.text);loadNotifs();try{if('Notification' in window&&Notification.permission==='granted')new Notification('EcoColeta',{body:d.text})}catch(x){}});
ES.addEventListener('ads',()=>soft(async()=>{await load(true);if(S.sheet){try{S.sheet=(await api('GET','/ads/'+S.sheet.id)).ad;render()}catch(e){S.sheet=null;render()}}}));
ES.addEventListener('msg',()=>soft(async()=>{if(S.chat){await loadMsgs();render()}else if(S.tab==='c')load()}));
ES.addEventListener('loc',e=>{const d=JSON.parse(e.data);if(CM)CM.setLatLng([d.lat,d.lng]);const a=S.mine.find(x=>x.id===d.ad);if(a)a.cpos={lat:d.lat,lng:d.lng}})}
function soft(f){const t=document.activeElement&&document.activeElement.tagName;if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT')return;f()}
function gps(){if(!navigator.geolocation){S.gps='no';return render()}if(wid!=null)navigator.geolocation.clearWatch(wid);
wid=navigator.geolocation.watchPosition(p=>{const first=S.gps!=='on';S.pos={lat:p.coords.latitude,lng:p.coords.longitude};S.gps='on';
if(UM)UM.setLatLng([S.pos.lat,S.pos.lng]);if(CM&&me&&me.role==='catador')CM.setLatLng([S.pos.lat,S.pos.lng]);
if(me&&me.role==='catador'&&(first||Date.now()-lastPost>10000)){lastPost=Date.now();api('POST','/me/location',S.pos).catch(()=>{})}
if(first){S.loc=null;load()}},()=>{S.gps='no';render();toast('Localização não permitida. Usando Valença-BA como padrão.')},{enableHighAccuracy:true,maximumAge:15000,timeout:20000})}

/* ---------- dados ---------- */
async function loadAds(){const p=new URLSearchParams({lat:P().lat,lng:P().lng,sort:S.sort});if(S.f)p.set('mat',S.f);if(S.mode)p.set('mode',S.mode);if(S.rad)p.set('radius',S.rad);if(S.q)p.set('q',S.q);S.ads=(await api('GET','/ads?'+p)).ads}
async function loadMine(){S.mine=(await api('GET','/ads?mine=1&lat='+P().lat+'&lng='+P().lng)).ads}
async function loadChats(){S.chats=(await api('GET','/chats')).chats}
async function loadMsgs(){const c=S.chat;S.msgs=(await api('GET',`/ads/${c.ad}/messages?cid=${c.cid}`)).msgs}
async function loadNotifs(){try{const r=await api('GET','/notifications');S.notifs=r.notifs;S.unseen=r.unseen;const b=$('#bd');if(b){b.textContent=S.unseen;b.style.display=S.unseen?'block':'none'}}catch(e){}}
async function load(quiet){try{const t=S.tab;if(t==='h'||t==='p')await loadAds();else if(t==='m')await loadMine();else if(t==='k'){S.cats=(await api('GET',`/catadores?lat=${P().lat}&lng=${P().lng}`)).catadores;await loadMine();await loadAds()}else if(t==='c')await loadChats()}catch(e){if(!quiet)toast(e.message)}
if(!S.chat&&!(document.activeElement&&document.activeElement.id==='sq'))render()}
const go=t=>{S.tab=t;S.chat=null;S.sheet=null;S.panel=false;load()};

/* ---------- mapas (OpenStreetMap + OSRM) ---------- */
function killMaps(){MAPS.forEach(m=>{try{m.remove()}catch(e){}});MAPS=[];UM=CM=null}
function newMap(id,c,z){if(typeof L==='undefined'||!$('#'+id)){return null}const m=L.map(id,{zoomControl:false}).setView(c,z);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(m);L.control.zoom({position:'topright'}).addTo(m);MAPS.push(m);return m}
const ic=(e,c)=>L.divIcon({className:'',html:`<div class="pin ${c||''}"><span>${e}</span></div>`,iconSize:[36,36],iconAnchor:c&&c.includes('me')?[18,18]:[8,36],popupAnchor:[10,-34]});
const fit=(m,pts)=>pts.length>1?m.fitBounds(pts,{padding:[34,34],maxZoom:17}):m.setView(pts[0],16);
async function route(m,a,b,rid){const el=()=>$('#'+rid);try{const r=await fetch(`https://router.project-osrm.org/route/v1/driving/${a.lng},${a.lat};${b.lng},${b.lat}?overview=full&geometries=geojson`);const j=await r.json(),rt=j.routes[0];
L.polyline(rt.geometry.coordinates.map(x=>[x[1],x[0]]),{color:'#15803d',weight:5,opacity:.85}).addTo(m);if(el())el().textContent=`🛣️ Rota real: ${fmtKm(rt.distance/1000)} · ${Math.max(1,Math.round(rt.duration/60))} min de carro`}
catch(e){try{L.polyline([[a.lat,a.lng],[b.lat,b.lng]],{color:'#15803d',weight:4,dashArray:'8'}).addTo(m)}catch(x){}if(el())el().textContent=`📏 Em linha reta: ${fmtKm(hv(a,b))}`}}
function pairMap(id,a,c,live){Q.push(()=>{const m=newMap(id,[a.lat,a.lng],15);if(!m)return;L.marker([a.lat,a.lng],{icon:ic(MATS[a.mat][1])}).addTo(m).bindPopup(esc(a.owner.name));
if(c){const mk=L.marker([c.lat,c.lng],{icon:ic('🛒','me cat2')}).addTo(m);if(live)CM=mk;fit(m,[[a.lat,a.lng],[c.lat,c.lng]]);route(m,c,a,id+'r')}else m.setView([a.lat,a.lng],16)})}

/* ---------- layout ---------- */
const tabs=()=>me.role==='catador'?[['h','🏠','Início'],['p','🗺️','Mapa'],['m','🛒','Coletas'],['c','💬','Chats']]:[['n','➕','Anunciar'],['m','📋','Anúncios'],['k','🗺️','Catadores'],['c','💬','Chats']];
const head=x=>`<header><div class="top"><button class="loc" onclick="gps()"><small>${me.role==='catador'?'Coletando perto de':'Meu ponto em'}</small><b>📍 ${S.gps==='on'?'Minha localização (GPS)':S.gps==='no'?'Valença-BA · ativar GPS':'Ativando localização…'} ▾</b></button>
<button class="bell" aria-label="Notificações" onclick="openPanel()">🔔<b id="bd" style="display:${S.unseen?'block':'none'}">${S.unseen}</b></button><button class="av" aria-label="Meu perfil" onclick="go('u')">${me.has_avatar?`<img alt="" src="/api/photo/user/${me.id}?v=${AV}">`:esc((me.name[0]||'?').toUpperCase())}</button></div>${x||''}</header>`;
function render(){killMaps();Q=[];const A=$('#app');if(!me){A.innerHTML=authView();return}
const v=S.chat?chatView():({h:home,p:mapTab,m:mine,k:catMap,n:form,c:threads,u:profile}[S.tab]||home)();
A.innerHTML=v+(S.sheet?sheet():'')+(S.panel?panel():'')+`<nav>${tabs().map(x=>`<button class="${S.tab===x[0]&&!S.chat?'on':''}" onclick="go('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('')}</nav>`;
Q.splice(0).forEach(f=>{try{f()}catch(e){console.error(e)}})}

/* ---------- login / cadastro ---------- */
function authView(){const r=S.reg;return `<header style="padding-bottom:22px"><h1 style="margin:12px 0 2px">♻️ EcoColeta</h1><div>Doe ou venda seus recicláveis. Catadores chegam até você.</div></header><main>
<div class="hero"><div><img alt="Fardos de garrafas PET para reciclagem" src="${cm(COMMONS.plastico)}" onerror="this.remove()"></div><div><img alt="Aço prensado para reciclagem" src="${cm(COMMONS.metal)}" onerror="this.remove()"></div></div>
<div class="card"><form onsubmit="return doAuth(event)">${r?`<label>Nome ou empresa</label><input id="n" required autocomplete="name"><label>Eu sou</label><select id="r" onchange="$('#kw').style.display=this.value==='fornecedor'?'block':'none'"><option value="catador">🛒 Catador(a)</option><option value="fornecedor">🏪 Tenho material para doar/vender</option></select>
<div id="kw" style="display:none"><label>Tipo de conta</label><select id="k"><option value="pessoa">👤 Pessoa</option><option value="empresa">🏢 Empresa</option></select></div><label>Telefone / WhatsApp</label><input id="ph" type="tel" autocomplete="tel">`:''}
<label>E-mail</label><input id="e" type="email" required autocomplete="email"><label>Senha</label><input id="p" type="password" required minlength="6" autocomplete="${r?'new-password':'current-password'}">
<button class="btn" style="width:100%">${r?'Criar conta':'Entrar'}</button></form><p style="text-align:center"><button class="btn g s" onclick="S.reg=!S.reg;render()">${r?'Já tenho conta':'Criar conta'}</button></p></div>
<p class="foot">Fotos: Wikimedia Commons (CC BY-SA) · Mapas © OpenStreetMap</p></main>`}
const doAuth=ev=>{ev.preventDefault();T(async()=>{const b={email:$('#e').value,password:$('#p').value};if(S.reg)Object.assign(b,{name:$('#n').value,role:$('#r').value,kind:$('#k')?.value,phone:$('#ph').value});
me=(await api('POST',S.reg?'/register':'/login',b)).user;S.reg=false;start();render()})();return false};
const logout=T(async()=>{await api('POST','/logout');if(ES)ES.close();me=null;S.sheet=S.chat=null;S.panel=false;render()});

/* ---------- cards e início ---------- */
const price=a=>a.mode==='venda'?`<span class="tg">R$ ${Number(a.price).toFixed(2).replace('.',',')}</span>`:'<span class="tg g">Doação grátis</span>';
const rc=a=>`<div class="rc" onclick="openSheet(${a.id})">${pic(a,'sm')}<div class="ri"><div class="row sp"><b>${MATS[a.mat][0]} · ${a.qty} ${a.unit}</b><span class="badge ${a.status}">${ST[a.status]}</span></div><span class="d">${esc(a.descr)}</span>
<div class="meta"><span>📍 ${a.dist!=null?fmtKm(a.dist):esc(a.addr)}</span>${a.dist!=null?`<span>🚶 ${eta(a.dist)}</span>`:''}<span>🕒 ${esc(a.hours)}</span></div><div class="row">${price(a)}<span class="mu">${esc(a.owner.name)}${a.owner.kind==='empresa'?' 🏢':''}</span></div></div></div>`;
const catsBar=()=>`<div class="cats"><button class="cat ${!S.f?'on':''}" onclick="setF('')"><i>🌎</i>Todos</button>${Object.entries(MATS).map(([k,v])=>`<button class="cat ${S.f===k?'on':''}" onclick="setF('${k}')"><i>${v[1]}</i>${v[0]}</button>`).join('')}</div>`;
const setF=f=>{S.f=f;load()};
const list=()=>S.ads.map(rc).join('')||'<div class="card mu">Nenhuma coleta encontrada com esses filtros.</div>';
function home(){return head(`<input class="search" id="sq" placeholder="Buscar material, local ou nome" value="${esc(S.q)}" oninput="clearTimeout(tmr);const v=this.value;tmr=setTimeout(()=>{S.q=v;T(async()=>{await loadAds();$('#lst').innerHTML=list();$('#cnt').textContent=S.ads.length})()},300)">`)+`<main>${catsBar()}
<div class="banner"><b><span id="cnt">${S.ads.length}</span> coletas disponíveis</b><span>Doações e vendas de recicláveis perto de você.</span></div>
<div class="chips">${[['dist','📍 Mais próximos'],['recent','🆕 Recentes']].map(x=>`<button class="chip ${S.sort===x[0]?'on':''}" onclick="S.sort='${x[0]}';load()">${x[1]}</button>`).join('')}${[['','Todas'],['doacao','🤝 Doação'],['venda','💰 Venda']].map(x=>`<button class="chip ${S.mode===x[0]?'on':''}" onclick="S.mode='${x[0]}';load()">${x[1]}</button>`).join('')}
<select class="f chip" aria-label="Raio de distância" onchange="S.rad=this.value;load()">${[['','Qualquer distância'],['1','até 1 km'],['5','até 5 km'],['10','até 10 km'],['25','até 25 km']].map(x=>`<option value="${x[0]}" ${S.rad===x[0]?'selected':''}>${x[1]}</option>`).join('')}</select></div>
<h2>Perto de você</h2><div id="lst">${list()}</div><p class="foot">Fotos: Wikimedia Commons (CC BY-SA) e usuários · Mapas © OpenStreetMap</p></main>`}

function mapTab(){Q.push(()=>{const m=newMap('bm',[P().lat,P().lng],14);if(!m)return;UM=L.marker([P().lat,P().lng],{icon:ic('🛒','me cat2')}).addTo(m).bindPopup('Você está aqui');const pts=[[P().lat,P().lng]];
S.ads.forEach(a=>{pts.push([a.lat,a.lng]);L.marker([a.lat,a.lng],{icon:ic(MATS[a.mat][1])}).addTo(m).bindPopup(`<b>${esc(a.owner.name)}</b><br>${MATS[a.mat][0]} · ${a.qty} ${a.unit} · ${fmtKm(a.dist)}<br><a href="#" onclick="openSheet(${a.id});return false">Ver detalhes e rota</a>`)});fit(m,pts)});
return head()+`<main>${catsBar()}<div id="bm" class="map big"></div><p class="mu">${S.ads.length} pontos disponíveis · toque num pino para ver detalhes.</p></main>`}
function catMap(){const c0=S.mine[0]||P();Q.push(()=>{const m=newMap('km',[c0.lat,c0.lng],14);if(!m)return;const pts=[];S.mine.filter(a=>a.mine&&a.status!=='concluida').forEach(a=>{pts.push([a.lat,a.lng]);L.marker([a.lat,a.lng],{icon:ic(MATS[a.mat][1])}).addTo(m).bindPopup('Seu anúncio: '+MATS[a.mat][0])});
S.cats.forEach(c=>{pts.push([c.lat,c.lng]);L.marker([c.lat,c.lng],{icon:ic('🛒','me cat2')}).addTo(m).bindPopup(`<b>${esc(c.name)}</b><br>Catador disponível${c.dist!=null?' · '+fmtKm(c.dist):''}`)});pts.length?fit(m,pts):m.setView([P().lat,P().lng],14)});
return head()+`<main><h2>Catadores disponíveis agora</h2><div id="km" class="map big"></div><div style="margin-top:12px">${S.cats.map(c=>`<div class="card">${who(c)}<span class="mu">${c.dist!=null?fmtKm(c.dist)+' de você':''}</span></div>`).join('')||'<div class="card mu">Nenhum catador compartilhando localização agora.</div>'}</div></main>`}

/* ---------- detalhe ---------- */
const openSheet=T(async id=>{S.panel=false;S.sheet=(await api('GET','/ads/'+id)).ad;render()});
function sheet(){const a=S.sheet,col=me.role==='catador'?P():a.cpos;a.dist=hv(P(),a);pairMap('mm',a,col);
return `<div class="ov" onclick="if(event.target===this){S.sheet=null;render()}"><div class="sheet"><button class="x" onclick="S.sheet=null;render()" aria-label="Fechar">✕</button>${pic(a,'lg')}<div class="in">
<div class="row sp"><h3>${MATS[a.mat][0]} · ${a.qty} ${a.unit}</h3><span class="badge ${a.status}">${ST[a.status]}</span></div><p>${esc(a.descr)}</p>${who(a.owner)}
<div class="mu" style="margin-top:8px">📍 ${esc(a.addr)}${me.role==='catador'?' · '+fmtKm(a.dist):''}<br>🕒 Disponível: ${esc(a.hours)}<br>${a.mode==='venda'?'💰 Venda: R$ '+Number(a.price).toFixed(2).replace('.',','):'🤝 Doação voluntária'}${a.owner.phone?`<br>📞 <a href="tel:${esc(a.owner.phone)}">${esc(a.owner.phone)}</a>`:''}${a.collector?`<br>🛒 Catador: ${esc(a.collector.name)}${a.collector.phone?` · <a href="tel:${esc(a.collector.phone)}">${esc(a.collector.phone)}</a>`:''}`:''}</div>
<div id="mm" class="map" style="margin:12px 0 4px"></div><p class="rt" id="mmr"></p><div class="row">${actions(a)}<button class="btn s g" onclick="openChat(${a.id})">💬 Chat</button><button class="btn s g" onclick="window.open('https://www.google.com/maps/dir/?api=1&destination=${a.lat},${a.lng}','_blank','noopener')">🧭 Abrir no GPS</button></div></div></div></div>`}
function actions(a){let h='';const act=['agendada','caminho'].includes(a.status);
if(me.role==='catador'&&a.status==='disponivel')h+=`<button class="btn" onclick="act(${a.id},'agendada')">Solicitar coleta</button>`;
if(a.mineCol&&a.status==='agendada')h+=`<button class="btn" onclick="act(${a.id},'caminho')">🚶 Iniciar trajeto</button>`;
if((a.mine||a.mineCol)&&act)h+=`<button class="btn s" onclick="act(${a.id},'concluida')">✔ Concluir</button><button class="btn s w" onclick="act(${a.id},'disponivel')">Cancelar</button>`;
if(a.mine&&!act)h+=`<button class="btn s g" onclick="del(${a.id})">Remover</button>`;return h}
const act=T(async(id,s)=>{await api('POST',`/ads/${id}/status`,{status:s});if(s==='agendada'){S.sheet=null;S.tab='m';toast('Coleta solicitada! Toque em Iniciar trajeto quando sair.')}else if(S.sheet)S.sheet=(await api('GET','/ads/'+id)).ad;await load()});
const del=T(async id=>{if(!confirm('Remover este anúncio?'))return;await api('DELETE','/ads/'+id);S.sheet=null;await load()});

/* ---------- coletas / anúncios ---------- */
function mine(){const L=S.mine,t=L.find(a=>['agendada','caminho'].includes(a.status)),idx={disponivel:0,agendada:1,caminho:2,concluida:3};let tr='';
if(t){const cp=me.role==='catador'?P():t.cpos;pairMap('lm',t,cp,true);
tr=`<div class="card"><div class="row sp"><h3>Coleta em andamento</h3><span class="badge ${t.status}">${ST[t.status]}</span></div><div class="steps">${['Disponível','Agendada','A caminho','Concluída'].map((s,i)=>`<div class="st ${i<=idx[t.status]?'on':''}">${s}</div>`).join('')}</div>
<div id="lm" class="map"></div><p class="rt" id="lmr"></p><p class="mu">${t.mineCol?`Destino: ${MATS[t.mat][1]} ${esc(t.owner.name)} · ${esc(t.addr)}`:cp?`🛒 ${esc(t.collector.name)} a caminho. Posição ao vivo no mapa.`:`🛒 ${esc(t.collector.name)} solicitou a retirada.`}</p><div class="row">${actions(t)}<button class="btn s g" onclick="openChat(${t.id})">💬 Chat</button></div></div>`}
return head()+`<main>${tr}<h2>${me.role==='fornecedor'?'Meus anúncios':'Minhas coletas'}</h2>${L.map(rc).join('')||'<div class="card mu">Nada por aqui ainda.</div>'}</main>`}

/* ---------- anunciar ---------- */
function form(){const p=S.loc||P();Q.push(()=>{const m=newMap('pk',[p.lat,p.lng],16);if(!m)return;const mk=L.marker([p.lat,p.lng],{icon:ic('📍'),draggable:true}).addTo(m);S.loc={lat:p.lat,lng:p.lng};
const set=ll=>{S.loc={lat:ll.lat,lng:ll.lng};mk.setLatLng(ll)};mk.on('dragend',()=>set(mk.getLatLng()));m.on('click',e=>set(e.latlng));window.pickMap={m,set}});
return head()+`<main><h2>Anunciar resíduo</h2><form class="card" onsubmit="return pub(event)">
<label>Material</label><select id="fm">${Object.entries(MATS).map(([k,v])=>`<option value="${k}">${v[1]} ${v[0]}</option>`).join('')}</select>
<label>Descrição</label><textarea id="fd" rows="2" required maxlength="300" placeholder="Ex.: Garrafas PET limpas, separadas"></textarea>
<div class="row" style="flex-wrap:nowrap"><div style="flex:1"><label>Quantidade</label><input id="fq" type="number" min="0.1" step="any" required></div><div style="flex:1"><label>Unidade</label><select id="fu"><option value="kg">kg</option><option value="un">unidades</option><option value="sacos">sacos</option></select></div></div>
<label>Foto real do material</label><input type="file" accept="image/*" capture="environment" onchange="photo(this)"><img id="pv" alt="" style="display:none;width:100%;max-height:180px;object-fit:cover;border-radius:12px;margin-bottom:10px">
<label>Modalidade</label><select id="fo" onchange="$('#fpw').style.display=this.value==='venda'?'block':'none'"><option value="doacao">🤝 Doação voluntária</option><option value="venda">💰 Quero receber pelo material</option></select>
<div id="fpw" style="display:none"><label>Valor total (R$)</label><input id="fp" type="number" min="0" step="0.01" value="0"></div>
<label>Endereço</label><div class="row" style="flex-wrap:nowrap"><input id="fa" required placeholder="Rua, número, bairro, cidade" style="margin:4px 0 10px"><button type="button" class="btn s" onclick="geo()" style="margin-bottom:6px">Localizar</button></div>
<label>Horário de disponibilidade</label><input id="fh" required placeholder="Ex.: 8h às 12h">
<label>Local da coleta (toque no mapa ou arraste o pino)</label><div id="pk" class="map" style="margin-bottom:10px"></div><button type="button" class="btn s g" onclick="usegps()" style="margin-bottom:12px">📍 Usar meu GPS</button>
<button class="btn" style="width:100%">Publicar anúncio</button></form></main>`}
const geo=T(async()=>{const q=$('#fa').value.trim();if(!q)return toast('Digite o endereço.');const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q)),j=await r.json();
if(!j.length)return toast('Endereço não encontrado. Ajuste o pino no mapa.');const ll={lat:+j[0].lat,lng:+j[0].lon};pickMap.set(ll);pickMap.m.setView([ll.lat,ll.lng],17)});
const usegps=()=>{if(S.gps!=='on')return toast('Ative o GPS (toque na localização no topo).');pickMap.set(S.pos);pickMap.m.setView([S.pos.lat,S.pos.lng],17)};
function photo(i,cb){const f=i.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,(cb?256:640)/im.width),c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);const d=c.toDataURL('image/jpeg',.7);if(cb)return cb(d);PH=d;const v=$('#pv');v.src=d;v.style.display='block'};im.src=r.result};r.readAsDataURL(f)}
const pub=ev=>{ev.preventDefault();T(async()=>{const l=S.loc||P();await api('POST','/ads',{mat:$('#fm').value,descr:$('#fd').value,qty:$('#fq').value,unit:$('#fu').value,photo:PH,mode:$('#fo').value,price:$('#fp')?.value,addr:$('#fa').value,hours:$('#fh').value,lat:l.lat,lng:l.lng});PH='';S.loc=null;toast('Anúncio publicado! Catadores próximos foram avisados.');go('m')})();return false};

/* ---------- chat ---------- */
function threads(){return head()+`<main><h2>Conversas</h2>${S.chats.map(t=>`<div class="rc" onclick="openThread(${t.ad.id},${t.cid})">${pic(t.ad,'sm')}<div class="ri"><b>${esc(t.with)}</b><span class="d">${esc(t.text)}</span><span class="mu">${MATS[t.ad.mat][0]} · ${t.ad.qty} ${t.ad.unit}</span></div></div>`).join('')||'<div class="card mu">Nenhuma conversa ainda. Abra um anúncio e toque em 💬 Chat.</div>'}</main>`}
const openThread=T(async(ad,cid)=>{S.chat={ad,cid};await loadMsgs();render()});
const openChat=T(async id=>{S.sheet=null;let cid=me.id;if(me.role==='fornecedor'){const r=await api('GET',`/chats`);const t=r.chats.find(c=>c.ad.id===id);if(!t){toast('Nenhum catador enviou mensagem ainda.');return render()}cid=t.cid}
S.chat={ad:id,cid,with:''};S.tab='c';await loadMsgs();render()});
function chatView(){Q.push(()=>{const e=$('#ms');if(e)e.scrollTop=e.scrollHeight});return head()+`<main><button class="btn s g" onclick="S.chat=null;load()">← Voltar</button><h2>Chat da coleta #${S.chat.ad}</h2><div class="card"><div class="msgs" id="ms">${S.msgs.map(m=>`<div class="m ${m.from_id===me.id?'me':''}"><small>${esc(m.name)}</small><br>${esc(m.text)}</div>`).join('')||'<span class="mu">Diga olá e combine a retirada.</span>'}</div>
<form class="row" onsubmit="return send(event)" style="flex-wrap:nowrap"><input id="mt" placeholder="Mensagem" required maxlength="500" style="margin:0"><button class="btn">Enviar</button></form></div></main>`}
const send=ev=>{ev.preventDefault();T(async()=>{const t=$('#mt').value.trim();if(!t)return;await api('POST',`/ads/${S.chat.ad}/messages`,{text:t,cid:S.chat.cid});await loadMsgs();render()})();return false};

/* ---------- notificações e perfil ---------- */
const openPanel=T(async()=>{await loadNotifs();S.panel=true;render();await api('POST','/notifications/read');S.unseen=0;const b=$('#bd');if(b)b.style.display='none'});
const panel=()=>`<div class="ov" onclick="if(event.target===this){S.panel=false;render()}"><div class="sheet"><div class="in"><div class="row sp"><h3>🔔 Notificações</h3><button class="btn s g" onclick="S.panel=false;render()">Fechar</button></div>${S.notifs.map(n=>`<div class="nt ${n.seen?'':'new'}" onclick="${n.ad_id?`openSheet(${n.ad_id})`:''}">${esc(n.text)}<small>${new Date(n.ts).toLocaleString('pt-BR')}</small></div>`).join('')||'<p class="mu">Sem notificações por enquanto.</p>'}</div></div></div>`;
function profile(){return head()+`<main><h2>Meu perfil</h2><div class="card"><div class="big-av" id="bav">${me.has_avatar?`<img alt="" src="/api/photo/user/${me.id}?v=${AV}">`:esc((me.name[0]||'?').toUpperCase())}</div>
<label>Foto de perfil (real)</label><input type="file" accept="image/*" onchange="photo(this,d=>{PA=d;$('#bav').innerHTML='<img alt=&quot;&quot; src=&quot;'+d+'&quot;>'})">
<label>Nome ${me.kind==='empresa'?'da empresa':''}</label><input id="un" value="${esc(me.name)}"><label>Telefone / WhatsApp</label><input id="up" type="tel" value="${esc(me.phone||'')}">
<button class="btn" style="width:100%" onclick="saveProfile()">Salvar perfil</button></div>
${me.role==='catador'?`<div class="card tgl"><div><b>Disponível para coletar</b><div class="mu">Compartilha sua localização com fornecedores.</div></div><input type="checkbox" aria-label="Disponível para coletar" ${me.online?'checked':''} onchange="setOnline(this.checked)"></div>`:''}
<button class="btn w" style="width:100%" onclick="logout()">Sair da conta</button></main>`}
const saveProfile=T(async()=>{me=(await api('PUT','/me',{name:$('#un').value,phone:$('#up').value,avatar:PA||undefined})).user;PA='';AV++;toast('Perfil salvo!');render()});
const setOnline=T(async v=>{await api('POST','/me/online',{online:v});me.online=v;toast(v?'Você está visível para fornecedores.':'Você está invisível.')});

boot();
