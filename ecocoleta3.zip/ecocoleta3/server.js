/* EcoColeta – servidor sem dependências: Node.js >= 22.5 (http + node:sqlite). Uso: node server.js */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
const PORT=process.env.PORT||3000,PUB=path.join(__dirname,'public');
const db=new DatabaseSync(process.env.DB_FILE||path.join(__dirname,'ecocoleta.db'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,salt TEXT,hash TEXT,role TEXT,kind TEXT DEFAULT 'pessoa',phone TEXT DEFAULT '',avatar TEXT,online INTEGER DEFAULT 0,lat REAL,lng REAL,lat_ts INTEGER,demo INTEGER DEFAULT 0,created INTEGER);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER,ts INTEGER);
CREATE TABLE IF NOT EXISTS ads(id INTEGER PRIMARY KEY,owner_id INTEGER,mat TEXT,descr TEXT,qty REAL,unit TEXT,photo TEXT,mode TEXT,price REAL DEFAULT 0,addr TEXT,lat REAL,lng REAL,hours TEXT,status TEXT DEFAULT 'disponivel',collector_id INTEGER,clat REAL,clng REAL,created INTEGER,updated INTEGER);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY,ad_id INTEGER,cid INTEGER,from_id INTEGER,text TEXT,ts INTEGER);
CREATE TABLE IF NOT EXISTS notifs(id INTEGER PRIMARY KEY,user_id INTEGER,text TEXT,ad_id INTEGER,ts INTEGER,seen INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS i_ads ON ads(status,mat);`);
const all=(s,...p)=>db.prepare(s).all(...p),one=(s,...p)=>db.prepare(s).get(...p),run=(s,...p)=>db.prepare(s).run(...p);
const MATS=['plastico','papelao','metal','cobre','eletronico','outros'],UNITS=['kg','un','sacos'],now=()=>Date.now();
const hav=(a,b,c,d)=>{const r=x=>x*Math.PI/180,h=Math.sin(r(c-a)/2)**2+Math.cos(r(a))*Math.cos(r(c))*Math.sin(r(d-b)/2)**2;return 12742*Math.asin(Math.sqrt(h))};
const hash=(pw,salt)=>crypto.scryptSync(pw,salt,32).toString('hex');

/* ---- tempo real (SSE) ---- */
const clients=new Map();
const push=(uid,ev,data={})=>(clients.get(uid)||[]).forEach(r=>r.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`));
const pushAll=(ev,data)=>clients.forEach((_,u)=>push(u,ev,data));
function notify(uid,text,adId){run('INSERT INTO notifs(user_id,text,ad_id,ts) VALUES(?,?,?,?)',uid,text,adId||null,now());push(uid,'notif',{text,ad:adId})}

/* ---- dados de demonstração ---- */
function seed(){if(one('SELECT 1 x FROM users'))return;
const LA=+process.env.SEED_LAT||-13.3697,LO=+process.env.SEED_LNG||-39.0731,salt=crypto.randomBytes(8).toString('hex');
const U=(n,k,la,lo)=>Number(run('INSERT INTO users(name,email,salt,hash,role,kind,demo,created,lat,lng,lat_ts) VALUES(?,?,?,?,?,?,1,?,?,?,?)',n,n.toLowerCase().replace(/\W+/g,'')+'@demo.local',salt,hash(crypto.randomBytes(9).toString('hex'),salt),'fornecedor',k,now(),LA+la,LO+lo,now()).lastInsertRowid);
const A=(o,m,d,q,u,mode,p,ad,h,la,lo)=>run('INSERT INTO ads(owner_id,mat,descr,qty,unit,mode,price,addr,hours,lat,lng,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',o,m,d,q,u,mode,p,ad,h,LA+la,LA*0+LO+lo,now()-36e5,now());
const m=U('Mercado Bom Preço','empresa',.004,.006),f=U('Oficina do Zé','empresa',-.006,.003),e=U('Escola Municipal','empresa',.009,-.005),c=U('Eletro Center','empresa',-.002,-.009),s=U('Maria Souza','pessoa',.012,.010),p=U('Padaria Pão Quente','empresa',.002,-.003);
A(m,'papelao','Caixas de papelão desmontadas e amarradas',40,'kg','doacao',0,'Rua da Matriz, 120','8h às 12h',.004,.006);
A(f,'metal','Sobras de alumínio e ferro',25,'kg','venda',2.5,'Av. Beira Rio, 45','14h às 18h',-.006,.003);
A(e,'plastico','Garrafas PET limpas',3,'sacos','doacao',0,'Rua das Flores, 8','Manhã',.009,-.005);
A(c,'eletronico','Monitores e placas antigas',12,'un','venda',40,'Praça Central, 3','Comercial',-.002,-.009);
A(s,'cobre','Fios de cobre descascados',6,'kg','venda',35,'Rua Nova, 77','Após 17h',.012,.010);
A(p,'plastico','Embalagens e galões plásticos',15,'un','doacao',0,'Rua do Comércio, 31','7h às 10h',.002,-.003);
[['José Catador',.001,.002],['Ana Recicla',-.004,-.002]].forEach(([n,a,b])=>run("INSERT INTO users(name,email,salt,hash,role,online,lat,lng,lat_ts,demo,created) VALUES(?,?,?,?,'catador',1,?,?,?,1,?)",n,n.split(' ')[0].toLowerCase()+'@demo.local',salt,hash('x',salt),LA+a,LO+b,now(),now()))}
seed();

/* ---- utilidades HTTP ---- */
const send=(res,code,obj,h={})=>{const b=JSON.stringify(obj);res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...h});res.end(b)};
const body=req=>new Promise((ok,no)=>{let b='',n=0;req.on('data',c=>{n+=c.length;if(n>4e6){no(new Error('grande'));req.destroy()}else b+=c});req.on('end',()=>{try{ok(b?JSON.parse(b):{})}catch(e){no(e)}})});
const cookie=req=>Object.fromEntries((req.headers.cookie||'').split(';').map(s=>s.trim().split('=')).filter(x=>x[0]));
const auth=req=>{const t=cookie(req).sid;if(!t)return null;return one('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?',t)||null};
const pubUser=u=>({id:u.id,name:u.name,role:u.role,kind:u.kind,phone:u.phone,has_avatar:!!u.avatar,online:!!u.online});
const S=(v,n)=>String(v??'').trim().slice(0,n),num=v=>Number.isFinite(+v)&&v!==''&&v!==null?+v:null;
const img=v=>typeof v==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(v)&&v.length<1.5e6?v:null;
function adOut(a,me,from){const inv=me&&(a.owner_id===me.id||a.collector_id===me.id);
const o={id:a.id,mat:a.mat,descr:a.descr,qty:a.qty,unit:a.unit,mode:a.mode,price:a.price,addr:a.addr,lat:a.lat,lng:a.lng,hours:a.hours,status:a.status,created:a.created,v:a.updated,has_photo:!!a.photo,
owner:{id:a.owner_id,name:a.ow,kind:a.okind,has_avatar:!!a.oav},collector:a.collector_id?{id:a.collector_id,name:a.cname,has_avatar:!!a.cav}:null,mine:me&&a.owner_id===me.id,mineCol:me&&a.collector_id===me.id};
if(inv){o.owner.phone=a.ophone;if(a.collector_id)o.collector.phone=a.cphone;if(a.clat!=null)o.cpos={lat:a.clat,lng:a.clng}}
if(from)o.dist=hav(from.lat,from.lng,a.lat,a.lng);return o}
const ADQ=`SELECT a.*,u.name ow,u.kind okind,u.phone ophone,(u.avatar IS NOT NULL) oav,c.name cname,c.phone cphone,(c.avatar IS NOT NULL) cav FROM ads a JOIN users u ON u.id=a.owner_id LEFT JOIN users c ON c.id=a.collector_id`;

/* ---- API ---- */
const routes=[];const R=(m,p,f)=>routes.push([m,new RegExp('^'+p.replace(/:(\w+)/g,'(?<$1>[^/]+)')+'$'),f]);
R('POST','/api/register',async(q,res)=>{const b=await body(q),email=S(b.email,120).toLowerCase(),name=S(b.name,80);
if(!name||!/^\S+@\S+\.\S+$/.test(email)||S(b.password,100).length<6)return send(res,400,{error:'Preencha nome, e-mail válido e senha com 6+ caracteres.'});
if(one('SELECT 1 x FROM users WHERE email=?',email))return send(res,409,{error:'Este e-mail já está cadastrado.'});
const role=b.role==='fornecedor'?'fornecedor':'catador',salt=crypto.randomBytes(8).toString('hex');
const id=Number(run('INSERT INTO users(name,email,salt,hash,role,kind,phone,avatar,created) VALUES(?,?,?,?,?,?,?,?,?)',name,email,salt,hash(b.password,salt),role,b.kind==='empresa'?'empresa':'pessoa',S(b.phone,30),img(b.avatar),now()).lastInsertRowid);
login(res,id,pubUser(one('SELECT * FROM users WHERE id=?',id)))});
function login(res,id,u){const t=crypto.randomBytes(24).toString('hex');run('INSERT INTO sessions VALUES(?,?,?)',t,id,now());send(res,200,{user:u},{'Set-Cookie':`sid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`})}
R('POST','/api/login',async(q,res)=>{const b=await body(q),u=one('SELECT * FROM users WHERE email=? AND demo=0',S(b.email,120).toLowerCase());
if(!u||!crypto.timingSafeEqual(Buffer.from(hash(S(b.password,100),u.salt)),Buffer.from(u.hash)))return send(res,401,{error:'E-mail ou senha incorretos.'});login(res,u.id,pubUser(u))});
R('POST','/api/logout',(q,res)=>{const t=cookie(q).sid;if(t)run('DELETE FROM sessions WHERE token=?',t);send(res,200,{ok:1},{'Set-Cookie':'sid=; Max-Age=0; Path=/'})});
R('GET','/api/me',(q,res,me)=>send(res,200,{user:me?pubUser(me):null}));
R('PUT','/api/me',async(q,res,me)=>{const b=await body(q);run('UPDATE users SET name=?,phone=?,avatar=COALESCE(?,avatar) WHERE id=?',S(b.name,80)||me.name,S(b.phone,30),img(b.avatar),me.id);send(res,200,{user:pubUser(one('SELECT * FROM users WHERE id=?',me.id))})});
R('POST','/api/me/online',async(q,res,me)=>{const b=await body(q);run('UPDATE users SET online=? WHERE id=?',b.online?1:0,me.id);send(res,200,{online:!!b.online})});
R('POST','/api/me/location',async(q,res,me)=>{const b=await body(q),la=num(b.lat),lo=num(b.lng);if(la==null||lo==null||Math.abs(la)>90||Math.abs(lo)>180)return send(res,400,{error:'Coordenadas inválidas.'});
run('UPDATE users SET lat=?,lng=?,lat_ts=? WHERE id=?',la,lo,now(),me.id);
all("SELECT id,owner_id FROM ads WHERE collector_id=? AND status='caminho'",me.id).forEach(a=>{run('UPDATE ads SET clat=?,clng=? WHERE id=?',la,lo,a.id);push(a.owner_id,'loc',{ad:a.id,lat:la,lng:lo})});send(res,200,{ok:1})});
R('GET','/api/photo/:k/:id',(q,res)=>{const {k,id}=q.params,r=k==='ad'?one('SELECT photo p FROM ads WHERE id=?',id):one('SELECT avatar p FROM users WHERE id=?',id);
if(!r||!r.p){res.writeHead(404);return res.end()}const m=/^data:(image\/\w+);base64,(.*)$/.exec(r.p);res.writeHead(200,{'Content-Type':m[1],'Cache-Control':'public, max-age=86400'});res.end(Buffer.from(m[2],'base64'))});
R('GET','/api/ads',(q,res,me)=>{const p=q.url.searchParams,la=num(p.get('lat')),lo=num(p.get('lng')),from=la!=null&&lo!=null?{lat:la,lng:lo}:null,rad=num(p.get('radius')),mat=p.get('mat'),mode=p.get('mode'),s=(p.get('q')||'').toLowerCase();
let L=all(ADQ+(p.get('mine')?' WHERE a.owner_id=? OR a.collector_id=?':" WHERE a.status='disponivel'"),...(p.get('mine')?[me.id,me.id]:[])).map(a=>adOut(a,me,from));
if(mat&&MATS.includes(mat))L=L.filter(a=>a.mat===mat);if(mode==='doacao'||mode==='venda')L=L.filter(a=>a.mode===mode);
if(s)L=L.filter(a=>(a.descr+a.owner.name+a.addr+a.mat).toLowerCase().includes(s));if(rad&&from)L=L.filter(a=>a.dist<=rad);
L.sort((a,b)=>p.get('sort')==='recent'?b.created-a.created:(a.dist??0)-(b.dist??0)||b.created-a.created);send(res,200,{ads:L})});
R('GET','/api/ads/:id',(q,res,me)=>{const a=one(ADQ+' WHERE a.id=?',q.params.id);a?send(res,200,{ad:adOut(a,me)}):send(res,404,{error:'Anúncio não encontrado.'})});
R('POST','/api/ads',async(q,res,me)=>{if(me.role!=='fornecedor')return send(res,403,{error:'Apenas fornecedores publicam.'});const b=await body(q),la=num(b.lat),lo=num(b.lng),qty=num(b.qty);
if(!MATS.includes(b.mat)||!S(b.descr,300)||!S(b.addr,160)||la==null||lo==null||!(qty>0))return send(res,400,{error:'Preencha material, descrição, quantidade, endereço e local no mapa.'});
const mode=b.mode==='venda'?'venda':'doacao',id=Number(run('INSERT INTO ads(owner_id,mat,descr,qty,unit,photo,mode,price,addr,lat,lng,hours,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',me.id,b.mat,S(b.descr,300),qty,UNITS.includes(b.unit)?b.unit:'kg',img(b.photo),mode,mode==='venda'?Math.max(0,num(b.price)||0):0,S(b.addr,160),la,lo,S(b.hours,60)||'A combinar',now(),now()).lastInsertRowid);
all("SELECT id,lat,lng FROM users WHERE role='catador' AND demo=0 AND lat IS NOT NULL AND id!=?",me.id).filter(u=>hav(u.lat,u.lng,la,lo)<=5).forEach(u=>notify(u.id,`Novo material (${b.mat}) a ${hav(u.lat,u.lng,la,lo).toFixed(1)} km de você`,id));
pushAll('ads');send(res,201,{id})});
R('DELETE','/api/ads/:id',(q,res,me)=>{const a=one('SELECT * FROM ads WHERE id=?',q.params.id);if(!a||a.owner_id!==me.id)return send(res,403,{error:'Sem permissão.'});if(['agendada','caminho'].includes(a.status))return send(res,409,{error:'Cancele a coleta antes de remover.'});run('DELETE FROM ads WHERE id=?',a.id);pushAll('ads');send(res,200,{ok:1})});
R('POST','/api/ads/:id/status',async(q,res,me)=>{const b=await body(q),a=one('SELECT * FROM ads WHERE id=?',q.params.id);if(!a)return send(res,404,{error:'Não encontrado.'});
const own=a.owner_id===me.id,col=a.collector_id===me.id,st=b.status,upd=(s,c,x)=>{run('UPDATE ads SET status=?,collector_id=?,clat=?,clng=?,updated=? WHERE id=?',s,c,x?x[0]:null,x?x[1]:null,now(),a.id);pushAll('ads');return send(res,200,{ok:1})};
if(st==='agendada'&&me.role==='catador'&&a.status==='disponivel'){notify(a.owner_id,`${me.name} agendou a coleta de ${a.mat}`,a.id);return upd('agendada',me.id)}
if(st==='caminho'&&col&&a.status==='agendada'){notify(a.owner_id,`${me.name} está a caminho!`,a.id);return upd('caminho',me.id,me.lat!=null?[me.lat,me.lng]:null)}
if(st==='concluida'&&(own||col)&&['agendada','caminho'].includes(a.status)){notify(own?a.collector_id:a.owner_id,'Coleta concluída. Obrigado por reciclar! ♻️',a.id);return upd('concluida',a.collector_id)}
if(st==='disponivel'&&(own||col)&&['agendada','caminho'].includes(a.status)){notify(own?a.collector_id:a.owner_id,'A coleta foi cancelada e o material voltou a ficar disponível.',a.id);return upd('disponivel',null)}
send(res,409,{error:'Ação não permitida para o estado atual.'})});
R('GET','/api/catadores',(q,res,me)=>{const p=q.url.searchParams,la=num(p.get('lat')),lo=num(p.get('lng'));
const L=all("SELECT id,name,phone,lat,lng,(avatar IS NOT NULL) hav FROM users WHERE role='catador' AND online=1 AND lat IS NOT NULL AND lat_ts>?",now()-15*6e4).map(u=>({id:u.id,name:u.name,has_avatar:!!u.hav,lat:u.lat,lng:u.lng,dist:la!=null?hav(la,lo,u.lat,u.lng):null}));send(res,200,{catadores:L})});
R('GET','/api/chats',(q,res,me)=>{const T=all('SELECT m.ad_id,m.cid,MAX(m.id) last FROM msgs m JOIN ads a ON a.id=m.ad_id WHERE a.owner_id=? OR m.cid=? GROUP BY m.ad_id,m.cid ORDER BY last DESC',me.id,me.id).map(t=>{const m=one('SELECT * FROM msgs WHERE id=?',t.last),a=one(ADQ+' WHERE a.id=?',t.ad_id),c=one('SELECT name FROM users WHERE id=?',t.cid);return{ad:adOut(a,me),cid:t.cid,with:me.id===t.cid?a.ow:c.name,text:m.text,ts:m.ts}});send(res,200,{chats:T})});
R('GET','/api/ads/:id/messages',(q,res,me)=>{const a=one('SELECT * FROM ads WHERE id=?',q.params.id),cid=me.role==='catador'?me.id:num(q.url.searchParams.get('cid'));if(!a||(a.owner_id!==me.id&&cid!==me.id))return send(res,403,{error:'Sem permissão.'});
send(res,200,{msgs:all('SELECT m.*,u.name FROM msgs m JOIN users u ON u.id=m.from_id WHERE ad_id=? AND cid=? ORDER BY m.id',a.id,cid),cid})});
R('POST','/api/ads/:id/messages',async(q,res,me)=>{const b=await body(q),a=one(ADQ+' WHERE a.id=?',q.params.id),text=S(b.text,500);if(!a||!text)return send(res,400,{error:'Mensagem inválida.'});
const cid=me.role==='catador'?me.id:num(b.cid);if(a.owner_id!==me.id&&cid!==me.id||cid==null)return send(res,403,{error:'Sem permissão.'});
run('INSERT INTO msgs(ad_id,cid,from_id,text,ts) VALUES(?,?,?,?,?)',a.id,cid,me.id,text,now());const other=me.id===a.owner_id?cid:a.owner_id;push(other,'msg',{ad:a.id,cid});notify(other,`💬 ${me.name}: ${text.slice(0,60)}`,a.id);
const ow=one('SELECT demo FROM users WHERE id=?',a.owner_id);if(ow.demo&&me.id===cid)setTimeout(()=>{run('INSERT INTO msgs(ad_id,cid,from_id,text,ts) VALUES(?,?,?,?,?)',a.id,cid,a.owner_id,'Olá! (resposta automática de demonstração) Pode vir buscar no horário informado. 😊',now());push(cid,'msg',{ad:a.id,cid})},2000);
send(res,201,{ok:1})});
R('GET','/api/notifications',(q,res,me)=>send(res,200,{notifs:all('SELECT * FROM notifs WHERE user_id=? ORDER BY id DESC LIMIT 30',me.id),unseen:one('SELECT COUNT(*) n FROM notifs WHERE user_id=? AND seen=0',me.id).n}));
R('POST','/api/notifications/read',(q,res,me)=>{run('UPDATE notifs SET seen=1 WHERE user_id=?',me.id);send(res,200,{ok:1})});
R('GET','/api/stream',(q,res,me)=>{res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});res.write('retry: 3000\n\n');
if(!clients.has(me.id))clients.set(me.id,new Set());clients.get(me.id).add(res);const hb=setInterval(()=>res.write(': ping\n\n'),25000);q.on('close',()=>{clearInterval(hb);clients.get(me.id)?.delete(res)})});
const OPEN=['/api/register','/api/login','/api/me','/api/logout'];

const MIME={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.json':'application/json','.ico':'image/x-icon'};
http.createServer(async(req,res)=>{try{req.url=new URL(req.url,'http://x');const p=decodeURIComponent(req.url.pathname);
if(p.startsWith('/api/')){const me=auth(req);if(me&&me.demo)return send(res,403,{error:'Conta de demonstração.'});
const hit=routes.find(r=>r[0]===req.method&&r[1].test(p));if(!hit)return send(res,404,{error:'Rota inexistente.'});
if(!me&&!OPEN.includes(p)&&!p.startsWith('/api/photo/'))return send(res,401,{error:'Faça login.'});req.params=hit[1].exec(p).groups||{};return await hit[2](req,res,me)}
const f=path.join(PUB,p==='/'?'index.html':p);if(!f.startsWith(PUB)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Não encontrado')}
res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(f).pipe(res)}
catch(e){console.error(e);if(!res.headersSent)send(res,500,{error:'Erro interno.'})}}).listen(PORT,()=>console.log(`EcoColeta rodando em http://localhost:${PORT}`));
