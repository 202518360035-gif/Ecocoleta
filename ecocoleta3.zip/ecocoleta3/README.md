# EcoColeta – plataforma de coleta seletiva

Backend sem dependências (Node.js ≥ 22.5, `http` + `node:sqlite`) e frontend em HTML/CSS/JS puro.

## Rodar
```
node server.js            # abre em http://localhost:3000
```
Variáveis opcionais: `PORT`, `DB_FILE` (caminho do banco SQLite), `SEED_LAT` e `SEED_LNG`
(centro dos pontos de demonstração, ex.: `SEED_LAT=-23.55 SEED_LNG=-46.63 node server.js`).
O banco `ecocoleta.db` é criado na primeira execução com 6 anúncios e 2 catadores de demonstração.

## Fotos reais
Coloque fotos suas em `public/fotos/` com o nome do material: `plastico.jpg`, `papelao.jpg`, `metal.jpg`,
`cobre.jpg`, `eletronico.jpg`, `outros.jpg`. Elas aparecem nos anúncios sem foto própria.
Fornecedores e catadores também enviam fotos de anúncio e de perfil (guardadas no banco).
Sem arquivo local, plástico e metal usam fotos do Wikimedia Commons (CC BY-SA).

## Publicar online
Hospede em qualquer servidor com Node 22.5+ (Render, Railway, VPS) atrás de HTTPS.
O GPS do navegador exige HTTPS (ou localhost).
Mapas: OpenStreetMap; rotas: OSRM público; busca de endereço: Nominatim (uso leve).
